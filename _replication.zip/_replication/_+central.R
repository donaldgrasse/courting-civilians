setwd('~/Dropbox/_replication')
source('_pgks.R')
source('_funs.R')

list.files("figs", full.names = TRUE) %>% purrr::walk(source)
beepr::beep(sound = 3)

list.files("tabs", full.names = TRUE) %>% purrr::walk(source)
beepr::beep(sound = 3)
