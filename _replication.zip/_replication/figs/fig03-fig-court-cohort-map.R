
#### Diagnostics on Treatment Cohorts #### 
afg_shp <- read_sf(dsn = "data/AFG_district_398/district398.shp")

court <- read.dta13("data/courts_treatement.dta")
court$newcourt_13 <- ifelse(court$treated_2013 == 1 & court$treated_2011==0 & court$treated_2012 ==0, 
                            1,0)
court$newcourt_12 <- ifelse(court$treated_2013 == 1 & court$treated_2011==0 & court$treated_2012 ==1, 
                            1,0)
court$withdraw_12 <- ifelse(court$treated_2011==1 & court$treated_2012 ==0, 
                            1,0)
court$withdraw_13 <- ifelse(court$treated_2013 == 0 & court$treated_2012 ==1, 
                            1,0)
court$wdl_12_est_13 <- ifelse(court$treated_2013 == 1 & court$treated_2012 ==0 
                              & court$treated_2011 ==1,
                              1,0)
afg_shp <- merge(afg_shp, court, by = 'DISTID')
sf_use_s2(FALSE)
afg_shp <- st_buffer(afg_shp, dist = 0)
afg_shp$cohort <- NA 
afg_shp$cohort[afg_shp$treated_always==1] <- '2011-2013'
afg_shp$cohort[afg_shp$newcourt_12==1] <- '2012-2013'
afg_shp$cohort[afg_shp$newcourt_13==1] <- '2013'
afg_shp$cohort[afg_shp$withdraw_12==1] <- 'WD. 2012'
afg_shp$cohort[afg_shp$withdraw_13==1] <- 'WD. 2013'
afg_shp$cohort[afg_shp$wdl_12_est_13==1] <- 'WD 2012, Est 2013'
afg_shp$cohort[is.na(afg_shp$cohort)] <- 'No Court'

#### Mapping spatial distribution of treatment groups #### 
court_map <- tm_shape(st_as_sf(afg_shp)) + 
  tm_fill('cohort', title = 'Treatment Cohort', 
          palette = 'RdGy') + 
  tm_shape(st_as_sf(afg_shp)) + tm_borders(col = 'black', alpha = .1) + 
  tm_layout(frame = FALSE) 


tmap_save(court_map, "fig-out/court_map.pdf")
