##### Conflict Outcomes Table #### 

pgks <- c('readstata13', 'dplyr', 'ggplot2', 'ggthemes', 
          'cowplot', 'sf', 'tjbal', 'tidyr', 'xtable')
setwd("~/Dropbox/_replication")
source('_pgks.R')
source('_funs.R')
theme_set(theme_tufte())

#### Levels #### 

df <- readRDS('DATA/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year < 2014) %>% 
  mutate(
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0)
  ) %>% 
  dplyr::select('aog_no_ied', 'ied', "DF", 
                "IED_Explosion", 'totalcas',
                'treat', 'DISTID', 'year', 'cohort', 'treated_ever')


#### Figure #### 
out_aog2 = tjbal(data = df, Y = "aog_no_ied", 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "none")

aog_lvl_plot <- make_tj_ct(out_aog2,  'Years until Taliban Courts', 'AOG Trend', '')
ggsave('fig-out/aog_lvl_plot.pdf', height = 6, width = 10)

out_aog2 = tjbal(data = df, Y = "ied", 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "none")
ied_anso_lvl_plot <- make_tj_ct(out_aog2,  'Years until Taliban Courts', 'IED Events', '')
ggsave('fig-out/ied_anso_lvl_plot.pdf', height = 6, width = 10)

out_aog2 = tjbal(data = df, Y = "DF", 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "none")
df_lvl_plot <- make_tj_ct(out_aog2,  'Years until Taliban Courts', 'Direct Fire', '')

ggsave('fig-out/df_lvl_plot.pdf', height = 6, width = 10)

out_aog2 = tjbal(data = df, Y = "IED_Explosion", 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "none")

ied_plot <- make_tj_ct(out_aog2,  'Years until Taliban Courts', 'IED Explosions', 
                       '')
ggsave('fig-out/ied_sigact_lvl_plot.pdf', height = 6, width = 10)

out_aog2 = tjbal(data = df, Y = "totalcas", 
                 D = "treat", 
                 index = c("DISTID", "year"), 
                 demean = F, estimator = "mean", 
                 vce = "none")

totcas_lvl_plot <- make_tj_ct(out_aog2,  'Years until Taliban Courts', 'Casualty Events', '')

ggsave('fig-out/totcas_lvl_plot.pdf', height = 6, width = 10)
