df = readRDS('data/full_panel_df.rds') %>% 
  filter(2007 < year) %>%
  filter(year < 2014)

lm(IED_Explosion ~ ied, data = df) %>% 
  summary()
  
ied_comparison_plot = ggplot(df, aes(ied, IED_Explosion)) + 
  geom_point() + 
  geom_smooth(aes(ied, IED_Explosion), method = 'loess') + 
  geom_abline(intercept = 0, slope = 1, size = 0.5, col = 'red', lty = 2) + 
  geom_label(aes(x = 400, y = 700, label ='Slope: 0.92\n Error: 0.02'), 
             family = 'Times') + 
  xlab('IED Events (ANSO)') + 
  ylab('IED Explosion Events (SIGACTs)')


ggsave('fig-out/ied_comparison_plot.pdf')
  

