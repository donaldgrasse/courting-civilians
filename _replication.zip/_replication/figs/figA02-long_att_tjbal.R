df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2006) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treated = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0), 
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0), 
    cohort = ifelse(cohort == '10000', '0', cohort)
  ) %>% 
  select('DISTID', 'year', 'cohort', 'treated', 'treat', 'treated_ever', 
         'aog', 'ied', 'IED_Explosion', 'DF', 'totalcas'
  ) 

pop = readRDS('data/pop_interpolation.rds')

df = merge(df, pop, by = c('DISTID', 'year'), all.x = T)
df = df %>% 
  mutate(
    DF_pc = (DF/ipop)*100000, 
    IED_pc = (IED_Explosion/ipop)*100000,
    cas_pc = (totalcas/ipop)*100000
  )
df = df %>% 
  mutate(
    DF_pc = log(DF_pc+1), 
    IED_pc = log(IED_pc+1), 
    cas_pc = log(cas_pc+1)
  )


m = tjbal(data = df, Y = 'DF', 
          D = "treat", 
      index = c("DISTID", "year"), 
      demean = F, estimator = "mean", 
      vce = "jackknife")
att_DF = make_tj_att(m, 'Years until Courts', '', '') + theme_bw()
ggsave('fig-out/att_DF.pdf', width = 6, height = 3)


m = tjbal(data = df, Y = 'IED_Explosion', 
          D = "treat", 
          index = c("DISTID", "year"), 
          demean = F, estimator = "mean", 
          vce = "jackknife")
att_IED = make_tj_att(m, 'Years until Courts', '', '') + theme_bw()
ggsave('fig-out/att_IED.pdf', width = 6, height = 3)


m = tjbal(data = df, Y = 'totalcas', 
          D = "treat", 
          index = c("DISTID", "year"), 
          demean = F, estimator = "mean", 
          vce = "jackknife")
att_cas = make_tj_att(m, 'Years until Courts', '', '') + theme_bw()
ggsave('fig-out/att_cas.pdf', width = 6, height = 3)

