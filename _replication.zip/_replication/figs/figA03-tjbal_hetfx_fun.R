
df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  select('DISTID', 'year', 'treated_ever', 'cohort') %>% 
  mutate(
    treated = ifelse(treated_ever, as.numeric(year >= cohort, 1,0), 0)
  ) 

anqar_indv = readRDS('data/anqar_indv.rds')

anqar_indv = merge(df, anqar_indv, by = c('DISTID', 'year'), 
                   all.x = T)
#### gender #### 
index_gender = het_fx(anqar_indv, anqar_indv$gender, anqar_indv$gov_index, 2008, 7)
return_gender = het_fx(anqar_indv, anqar_indv$gender, anqar_indv$return_good, 2009, 6)
dispute_gender = het_fx(anqar_indv, anqar_indv$gender, anqar_indv$dispute_court, 2009, 6)
inf_gender = het_fx(anqar_indv, anqar_indv$gender, anqar_indv$gov_influence, 2008, 7)

#### pashtun #### 

index_pashtun = het_fx(anqar_indv, anqar_indv$pashtun, anqar_indv$gov_index, 2008, 7)
return_pashtun = het_fx(anqar_indv, anqar_indv$pashtun, anqar_indv$return_good, 2009, 6)
dispute_pashtun = het_fx(anqar_indv, anqar_indv$pashtun, anqar_indv$dispute_court, 2009, 6)
inf_pashtun = het_fx(anqar_indv, anqar_indv$pashtun, anqar_indv$gov_influence, 2008, 7)

#### ses #### 

index_ses = het_fx(anqar_indv, 
                   anqar_indv$ses_hm, 
                   anqar_indv$gov_index, 2008, 6)
return_ses = het_fx(anqar_indv, 
                    anqar_indv$ses_hm, 
                    anqar_indv$return_good, 2009, 5)
dispute_ses = het_fx(anqar_indv, anqar_indv$ses_hm, 
                     anqar_indv$dispute_court, 2009, 5)
inf_ses = het_fx(anqar_indv, anqar_indv$ses_hm, 
                 anqar_indv$gov_influence, 2008, 6)

att_df = rbind.data.frame(
rbind.data.frame(index_ses, return_ses, dispute_ses, inf_ses), 
rbind.data.frame(index_pashtun, return_pashtun, dispute_pashtun, inf_pashtun), 
rbind.data.frame(index_gender, return_gender, dispute_gender, inf_gender)
)

att_df = cbind.data.frame(att_df, mod = c(rep('SES', 4), rep('Pashtun', 4), 
                                          rep('Female', 4)))
att_df$reject_null = ifelse(att_df$p_value < .1, 'y', "")
att_df$outcome = rep(c('Index', 'TLB Support', 'Gov. Court', 'Influence')) 

attitude_het_fx = ggplot(att_df, aes(p_value, diff_out, shape = mod)) +
  xlab('P-value') + 
  ylab('Scaled Difference in ATT') + 
  geom_vline(xintercept = .05, col = 'red') + 
  geom_hline(yintercept = 0, col = 'red') + 
  scale_shape_discrete(name="Moderator", labels=c('Female', 'Pashtun', 'High SES')) + 
  facet_wrap( ~ outcome, nrow = 2) + 
  geom_point(size = 4) + 
  #geom_point(data = att_df[att_df$reject_null == "",], color = "grey50", size = 4) +
  #geom_label_repel(box.padding = 0.5, max.overlaps = Inf) +
 # geom_point(data = att_df[att_df$reject_null != "",], color = "red", size = 4) + 
  theme(legend.position="bottom")

ggsave('fig-out/attitude_het_fx.pdf')

