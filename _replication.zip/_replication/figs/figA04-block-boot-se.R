
anqar_panel = readRDS('data/anqar_panel_2023.rds')
df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  filter(year >= 2008) %>% 
  filter(year <= 2014) %>% 
  mutate(
    treated = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0), 
    treat = ifelse(treated_ever==1, as.numeric(year>=cohort, 1,0), 0), 
    cohort = ifelse(cohort == '10000', '0', cohort)
  ) %>% 
  select('DISTID', 'year', 'cohort', 'treated', 'treat', 'treated_ever', 
         'aog_no_ied', 'ied', 'IED_Explosion', 'DF', 'totalcas'
  ) 
df = merge(df, anqar_panel, by = c('DISTID', 'year'), all.x = T)
outcome_list = c('aog_no_ied', 'ied', 'DF', 'IED_Explosion', 
                 'totalcas', 'dispute_court', 'return_good', 
                 'gov_index2', 'gov_influence')
J = 10 
t_stat = list()


df2 = df %>%  
  filter(year >= 2008) %>% 
  filter(year <= 2013) 

for (j in 1:5) {
  
  t_stat[j] = tjbal_block_boot(df2, 'DISTID', 'year',  outcome_list[j], 'treat', 
                   nboot = 200)[3]
  
}

for (j in 6:9) {
  
  t_stat[j] = tjbal_block_boot(df, 'DISTID', 'year',  outcome_list[j], 'treat', 
                               nboot = 200)[3]
  
}


plot_df = cbind.data.frame(unlist(t_stat), outcome_list)
colnames(plot_df)[1:2] = c('t_value', 'outcomes')
plot_df$outcomes = c('AOG','IED', 'Direct Fire', 
                     'IED (SIGACT)', 'Casualties', 
                     'State Court', 'Taliban Approval', 
                     'Gov. Influence', 'Gov. Index'
                     )

block_bootstrap_plot = plot_df %>% 
  ggplot(., aes(abs(t_value), outcomes)) + 
  geom_point(aes(size = abs(t_value))) + 
  geom_vline(xintercept = 1.96) + 
  geom_vline(xintercept = 1.65, lty = 2) + 
  scale_size_continuous('t-value') + 
  theme_minimal() + 
  xlab('|t-value|') + 
  ylab('Outcomes') + 
  theme(legend.position = 'bottom') 

ggsave('fig-out/block_bootstrap_plot.pdf', width = 4, height = 5)


