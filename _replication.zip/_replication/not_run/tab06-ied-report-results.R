#### Packages, Working Directory, Theme Set #### 

anqar <- read.dta13("data/ANQAR_ALL.dta")

#Q176: Between the two, the Anti- Government Elements (Mukhalafeen-e dawlat) and the Government, who has more influence in your mantaqa now?

anqar$gov_influence <- as.numeric(anqar$Q176 == "Government (District, Provincial, Police, etc.)", 1,0 )


#Q312
# Had a dispute, where do you go 
anqar$dispute_jirga <- as.numeric(anqar$Q312=="To a local shura/jirga", 1,0)
anqar$dispute_jirga[anqar$Q312=='Refused'] <- NA
anqar$dispute_jirga[anqar$Q312=="Don't Know"] <- NA
anqar$dispute_jirga[is.na(anqar$Q312)] <- NA

anqar$dispute_court <- as.numeric(anqar$Q312=="To an Afghanistan state court", 1,0)
anqar$dispute_court[anqar$Q312=='Refused'] <- NA
anqar$dispute_court[anqar$Q312=="Don't Know"] <- NA
anqar$dispute_court[is.na(anqar$Q312)] <- NA

anqar$dispute_other <- as.numeric(anqar$Q312=="Neither", 1,0)
anqar$dispute_other[anqar$Q312=='Refused'] <- NA
anqar$dispute_other[anqar$Q312=="Don't Know"] <- NA
anqar$dispute_other[is.na(anqar$Q312)] <- NA

anqar$dispute_refused <- as.numeric(anqar$Q312 == 'Refused', 1,0)
anqar$dispute_refused[anqar$Q312=="Don't Know"] <- NA


#If you saw an IED, would you report it
anqar$IED_report <- as.character(anqar$Q457)
anqar$IED_report[anqar$IED_report=="Very likely"] <- 4
anqar$IED_report[anqar$IED_report=="Somewhat likely"] <- 3
anqar$IED_report[anqar$IED_report=="Somewhat unlikely"] <- 2
anqar$IED_report[anqar$IED_report=="Very unlikely"] <- 1
anqar$IED_report <- as.numeric(anqar$IED_report)
anqar$IED_report_bin <- ifelse(anqar$IED_report > 0, as.numeric(anqar$IED_report), NA)
anqar$IED_report_bin <- as.numeric(anqar$IED_report_bin > 2, 1,0)

anqar_ied <- anqar %>% 
  filter(Wave > 19 & Wave < 25)

m1 <- felm(IED_report_bin ~ dispute_court + dispute_jirga + poly(Age, 2) + gov_influence|  + Gender + Ethnic | 0 | DISTID, data = anqar_ied)
m2 <- felm(IED_report_bin ~ dispute_court + dispute_jirga + poly(Age, 2) + gov_influence| Wave + DISTID + Gender + Ethnic | 0 | DISTID, data = anqar_ied)
m3 <- felm(IED_report ~ dispute_court + dispute_jirga + poly(Age, 2) + gov_influence | Wave + DISTID + Gender + Ethnic | 0 | DISTID, data = anqar_ied)
m4 <- felm(IED_report ~ dispute_court + dispute_jirga + poly(Age, 2) + gov_influence| + Gender + Ethnic | 0 | DISTID, data = anqar_ied)
texreg::texreg(list(m1, m2, m3, m4), include.ci = F)


