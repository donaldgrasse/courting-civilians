#### attitudes #### 
anqar_panel = readRDS('data/anqar_panel_2023.rds')
df <- readRDS('data/full_panel_df.rds') %>% 
  filter(cohort == "2011" | cohort == "2012" | cohort == '2013' | cohort == '10000') %>% 
  select('DISTID', 'year', 'treated_ever', 'cohort') %>% 
  mutate(
    treated = ifelse(treated_ever, as.numeric(year >= cohort, 1,0), 0)
  )
df = merge(df, anqar_panel, by = c("DISTID", 'year'), 
           all.x = T) 

return_df = df %>% 
  filter(year > 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(return_good)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

use_df = df %>% 
  filter(year > 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(dispute_court)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

control_df = df %>% 
  filter(year >= 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(gov_influence)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()

gov_df = df %>% 
  filter(year >= 2008) %>% 
  group_by(DISTID) %>% 
  mutate(NA_data = mean(gov_index2)) %>% 
  filter(is.na(NA_data ) == F) %>% 
  as.data.frame()


out1 <- tjbal(data = use_df, Y = "dispute_court", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out2 <- tjbal(data = return_df, Y = "return_good", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out3 <- tjbal(data = control_df, Y = "gov_influence", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")
out4 <- tjbal(data = gov_df, Y = "gov_index2", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'mean',
              vce = "jackknife")

outcome_table = cbind.data.frame(
  'State Court' =  print(out1)[c(1,2,6)],
  'Taliban Approval' =  print(out2)[c(1,2,6)],
  'Gov. Influence' =  print(out3)[c(1,2,6)],
  'Gov. Index' = print(out4)[c(1,2,6)]
)

outcome_table = rbind.data.frame(outcome_table, 
                                 'N. District' = c('170', '170', '194', '187'),
                                 'N. Year' = c('6', '6', '7', '7'), 
                                 'Sd. DV' = 
                                   c(round(sd(use_df$dispute_court),2), 
                                     round(sd(return_df$return_good), 2), 
                                     round(sd(control_df$gov_influence), 2), 
                                     round(sd(gov_df$gov_index2), 2)),
                                 'Mean DV' = 
                                   c(round(mean(use_df$dispute_court),2), 
                                     round(mean(return_df$return_good), 2), 
                                     round(mean(control_df$gov_influence), 2), 
                                     round(mean(gov_df$gov_index2), 2)
                                   ))

print.xtable(xtable(outcome_table), booktabs = T, include.rownames = F, file="tables/opinion_table_baseline.tex")



out1 <- tjbal(data = use_df, Y = "dispute_court", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'kernel',
              vce = "jackknife")
out2 <- tjbal(data = return_df, Y = "return_good", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'kernel',
              vce = "jackknife")
out3 <- tjbal(data = control_df, Y = "gov_influence", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'kernel',
              vce = "jackknife")
out4 <- tjbal(data = gov_df, Y = "gov_index2", D = "treated",  
              index = c("DISTID","year"), demean = F, estimator = 'kernel',
              vce = "jackknife")

outcome_table = cbind.data.frame(
  'State Court' =  print(out1)[c(1,2,6)],
  'Taliban Approval' =  print(out2)[c(1,2,6)],
  'Gov. Influence' =  print(out3)[c(1,2,6)],
  'Gov. Index' = print(out4)[c(1,2,6)]
)

outcome_table = rbind.data.frame(outcome_table, 
                                 'N. District' = c('170', '170', '194', '187'),
                                 'N. Year' = c('6', '6', '7', '7'), 
                                 'Sd. DV' = 
                                   c(round(sd(use_df$dispute_court),2), 
                                     round(sd(return_df$return_good), 2), 
                                     round(sd(control_df$gov_influence), 2), 
                                     round(sd(gov_df$gov_index2), 2)),
                                 'Mean DV' = 
                                   c(round(mean(use_df$dispute_court),2), 
                                     round(mean(return_df$return_good), 2), 
                                     round(mean(control_df$gov_influence), 2), 
                                     round(mean(gov_df$gov_index2), 2)
                                   ))

print.xtable(xtable(outcome_table), booktabs = T, include.rownames = F, 
             file="tables/opinion_table_kernel.tex")







